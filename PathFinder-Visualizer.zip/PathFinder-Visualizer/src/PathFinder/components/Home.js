import React, { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div className="mt-3 d-flex justify-content-left">
        <h4>This is the Home page.</h4>
      </div>
    );
  }
}
